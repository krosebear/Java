public class HashMappingTest {
  public static void main(String[] args){
    HashMapping hash = new HashMapping();
    hash.printSongLyrics();
  }
}
